package com.salesianostriana.dam.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IndexController {

	@GetMapping("/Dashboard")
	public String pintarDashboard() {
		return "Dashboard";
	}
	
}
